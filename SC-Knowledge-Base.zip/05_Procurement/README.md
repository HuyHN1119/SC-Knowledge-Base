# 05_Procurement

Supplier management, sourcing, RFQ, should-cost.

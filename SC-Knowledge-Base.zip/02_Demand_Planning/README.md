# 02_Demand_Planning

Forecasting, replenishment, segmentation, S&OP.

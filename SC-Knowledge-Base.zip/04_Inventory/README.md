# 04_Inventory

Inventory health, safety stock, service level, excess stock.

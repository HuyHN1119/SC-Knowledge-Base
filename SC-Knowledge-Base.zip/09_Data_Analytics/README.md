# 09_Data_Analytics

Excel, SQL, Power BI, Python, statistics.

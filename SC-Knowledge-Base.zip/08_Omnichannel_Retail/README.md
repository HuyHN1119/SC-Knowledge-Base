# 08_Omnichannel_Retail

Allocation, assortment, markdown, omnichannel fulfillment.

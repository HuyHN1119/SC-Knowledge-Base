# 01_Business

Kiến thức business, tài chính và unit economics liên quan Supply Chain.

# 14_Templates

Template KPI, scorecard, dashboard, RCA.

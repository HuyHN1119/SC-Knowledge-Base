# Supply Chain Knowledge Base
Kho tri thức Supply Chain, Planning, Logistics và Optimization.

## Cấu trúc
- 01_Business
- 02_Demand_Planning
- 03_Supply_Planning
- 04_Inventory
- 05_Procurement
- 06_Logistics
- 07_Warehouse
- 08_Omnichannel_Retail
- 09_Data_Analytics
- 10_Optimization
- 11_Projects
- 12_Case_Studies
- 13_Content
- 14_Templates

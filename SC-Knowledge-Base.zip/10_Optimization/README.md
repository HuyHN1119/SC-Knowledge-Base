# 10_Optimization

LP, MIP, simulation, OR tools, AI applications.
